-- Plataforma escolar Tualali (SQLite)
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS escolas (
  id INTEGER PRIMARY KEY, nome TEXT NOT NULL, cidade TEXT, criado TEXT DEFAULT (datetime('now','localtime')));

-- papel: adm | professor | editora
CREATE TABLE IF NOT EXISTS usuarios (
  id INTEGER PRIMARY KEY, escola_id INTEGER REFERENCES escolas(id), papel TEXT NOT NULL,
  nome TEXT NOT NULL, email TEXT NOT NULL UNIQUE COLLATE NOCASE, senha_hash TEXT NOT NULL,
  editora TEXT, criado TEXT DEFAULT (datetime('now','localtime')));

CREATE TABLE IF NOT EXISTS salas (
  id INTEGER PRIMARY KEY, escola_id INTEGER NOT NULL REFERENCES escolas(id), nome TEXT NOT NULL, serie TEXT);

-- sala_ciclo: ciclo (ex. 2026-2) em que o aluno foi colocado na sala; visto_ciclo: ultimo ciclo
-- em que o computador do aluno passou pelo beacon. Em 31/07 e 01/01 comeca um ciclo novo.
CREATE TABLE IF NOT EXISTS alunos (
  id INTEGER PRIMARY KEY, escola_id INTEGER NOT NULL REFERENCES escolas(id), nome TEXT NOT NULL,
  matricula TEXT, sala_id INTEGER REFERENCES salas(id), sala_ciclo TEXT, visto_ciclo TEXT,
  visto_em TEXT);

CREATE TABLE IF NOT EXISTS horarios (
  id INTEGER PRIMARY KEY, sala_id INTEGER NOT NULL REFERENCES salas(id) ON DELETE CASCADE,
  professor_id INTEGER NOT NULL REFERENCES usuarios(id), disciplina TEXT NOT NULL,
  dia INTEGER NOT NULL, inicio TEXT NOT NULL, fim TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS beacons (
  id INTEGER PRIMARY KEY, escola_id INTEGER NOT NULL REFERENCES escolas(id),
  identificador TEXT NOT NULL UNIQUE COLLATE NOCASE, nome TEXT);

CREATE TABLE IF NOT EXISTS dispositivos (
  id INTEGER PRIMARY KEY, token TEXT NOT NULL UNIQUE, codigo TEXT NOT NULL UNIQUE, nome TEXT,
  escola_id INTEGER REFERENCES escolas(id), aluno_id INTEGER REFERENCES alunos(id),
  modo TEXT, ultimo_contato TEXT, criado TEXT DEFAULT (datetime('now','localtime')));

CREATE TABLE IF NOT EXISTS livros (
  id INTEGER PRIMARY KEY, editora_id INTEGER NOT NULL REFERENCES usuarios(id), titulo TEXT NOT NULL,
  autor TEXT, serie TEXT, arquivo TEXT NOT NULL, criado TEXT DEFAULT (datetime('now','localtime')));

CREATE TABLE IF NOT EXISTS livros_sala (
  sala_id INTEGER NOT NULL REFERENCES salas(id) ON DELETE CASCADE,
  livro_id INTEGER NOT NULL REFERENCES livros(id) ON DELETE CASCADE, PRIMARY KEY (sala_id, livro_id));

CREATE TABLE IF NOT EXISTS ocorrencias (
  id INTEGER PRIMARY KEY, escola_id INTEGER NOT NULL, aluno_id INTEGER NOT NULL REFERENCES alunos(id),
  professor_id INTEGER NOT NULL REFERENCES usuarios(id), texto TEXT NOT NULL,
  criado TEXT DEFAULT (datetime('now','localtime')));

-- tipo: prova | atividade
CREATE TABLE IF NOT EXISTS atividades (
  id INTEGER PRIMARY KEY, escola_id INTEGER NOT NULL, sala_id INTEGER NOT NULL REFERENCES salas(id),
  professor_id INTEGER NOT NULL REFERENCES usuarios(id), titulo TEXT NOT NULL, tipo TEXT NOT NULL,
  prazo TEXT, publicada INTEGER DEFAULT 0, criado TEXT DEFAULT (datetime('now','localtime')));

-- tipo: escrita | selecao | desenho ; opcoes: uma por linha ; correta: indice (selecao)
CREATE TABLE IF NOT EXISTS questoes (
  id INTEGER PRIMARY KEY, atividade_id INTEGER NOT NULL REFERENCES atividades(id) ON DELETE CASCADE,
  ordem INTEGER NOT NULL, tipo TEXT NOT NULL, enunciado TEXT NOT NULL, opcoes TEXT, correta INTEGER);

CREATE TABLE IF NOT EXISTS respostas (
  id INTEGER PRIMARY KEY, atividade_id INTEGER NOT NULL REFERENCES atividades(id) ON DELETE CASCADE,
  aluno_id INTEGER NOT NULL REFERENCES alunos(id), enviada TEXT DEFAULT (datetime('now','localtime')),
  UNIQUE (atividade_id, aluno_id));

CREATE TABLE IF NOT EXISTS resposta_itens (
  resposta_id INTEGER NOT NULL REFERENCES respostas(id) ON DELETE CASCADE,
  questao_id INTEGER NOT NULL REFERENCES questoes(id) ON DELETE CASCADE, valor TEXT,
  PRIMARY KEY (resposta_id, questao_id));

CREATE TABLE IF NOT EXISTS cadernos (
  id INTEGER PRIMARY KEY, aluno_id INTEGER NOT NULL REFERENCES alunos(id), titulo TEXT NOT NULL,
  texto TEXT DEFAULT '', atualizado TEXT DEFAULT (datetime('now','localtime')));
