"""Testes de ponta a ponta da plataforma escolar Tualali.
Rodar:  cd plataforma && python3 -m unittest -v tests/test_plataforma.py"""
import io
import os
import re
import shutil
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import app as plataforma  # noqa: E402

PDF = b"%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj 2 0 obj<</Type/Pages/Kids[]/Count 0>>endobj\ntrailer<</Root 1 0 R>>\n%%EOF\n"
PNG = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg=="


class Navegador:
    """Cliente com cookie de sessao proprio e token CSRF automatico."""

    def __init__(self, app, host="localhost"):
        self.c = app.test_client()
        self.host = host

    def get(self, url, **k):
        return self.c.get(url, headers={"Host": self.host}, **k)

    def post(self, url, dados=None, csrf=True, **k):
        dados = dict(dados or {})
        if csrf:
            with self.c.session_transaction() as s:
                s.setdefault("csrf", "tok-teste")
                dados["csrf"] = s["csrf"]
        return self.c.post(url, data=dados, headers={"Host": self.host}, **k)

    def api(self, url, json):
        return self.c.post(url, json=json)


class TestPlataforma(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.mkdtemp()
        os.environ["TUALALI_DADOS"] = self.dir
        self.ciclo_original = plataforma.ciclo_atual
        self.app = plataforma.criar_app({"TESTING": True})

    def tearDown(self):
        plataforma.ciclo_atual = self.ciclo_original
        shutil.rmtree(self.dir)

    # ---------------------------------------------------------- auxiliares
    def nova_escola(self, nome="Escola Tualali", email="adm@escola.com"):
        adm = Navegador(self.app)
        r = adm.post("/adm/cadastro", {"escola": nome, "cidade": "SP", "nome": "Ana Adm", "email": email,
                                       "senha": "senha-forte-1"})
        self.assertEqual(r.status_code, 302)
        return adm

    def entrar(self, area, email, senha):
        n = Navegador(self.app)
        r = n.post("/%s/entrar" % area, {"email": email, "senha": senha})
        self.assertEqual(r.status_code, 302, r.data[:300])
        return n

    def id_de(self, tabela, campo, valor):
        with self.app.app_context():
            return self.app.um("SELECT id FROM %s WHERE %s=?" % (tabela, campo), valor)["id"]

    def montar_escola_completa(self):
        adm = self.nova_escola()
        adm.post("/adm/professores", {"nome": "Paulo Prof", "email": "paulo@escola.com", "senha": "prof-senha-1"})
        adm.post("/adm/salas", {"nome": "7º A", "serie": "7º ano"})
        sala = self.id_de("salas", "nome", "7º A")
        prof = self.id_de("usuarios", "email", "paulo@escola.com")
        r = adm.post("/adm/salas/%d" % sala, {"acao": "horario", "professor": prof, "disciplina": "Matemática",
                                              "dia": 0, "inicio": "07:30", "fim": "08:20"})
        self.assertEqual(r.status_code, 302)
        adm.post("/adm/beacons", {"acao": "criar", "identificador": "AA:BB:CC:DD:EE:01", "nome": "Porta 7A"})
        ed = Navegador(self.app)
        ed.post("/editora/cadastro", {"editora": "Editora Saber", "nome": "Eva", "email": "eva@saber.com",
                                      "senha": "editora-senha"})
        r = ed.post("/editora/", {"acao": "publicar", "titulo": "Matemática 7", "autor": "Eva", "serie": "7º ano",
                                  "pdf": (io.BytesIO(PDF), "mat7.pdf")}, content_type="multipart/form-data")
        self.assertEqual(r.status_code, 302)
        livro = self.id_de("livros", "titulo", "Matemática 7")
        adm.post("/adm/salas/%d" % sala, {"acao": "livros", "livro": livro})
        return adm, ed, sala, prof, livro

    def computador_do_aluno(self, adm, nome="Bruno Aluno"):
        disp = Navegador(self.app)
        reg = disp.api("/api/dispositivo/registrar", {"nome": "macbook-air"}).get_json()
        tok = reg["token"]
        self.assertIn("AA:BB:CC:DD:EE:01", disp.api("/api/dispositivo/beacons", {"token": tok}).get_json()["beacons"])
        ev = disp.api("/api/dispositivo/evento", {"token": tok, "beacon": "AA:BB:CC:DD:EE:01", "modo": "aula"}).get_json()
        self.assertFalse(ev["liberado"])
        self.assertIn(reg["codigo"].encode(), adm.get("/adm/computadores").data)
        did = self.id_de("dispositivos", "token", tok)
        r = adm.post("/adm/computadores", {"acao": "vincular", "dispositivo": did, "aluno": "novo", "nome": nome})
        self.assertEqual(r.status_code, 302)
        ev = disp.api("/api/dispositivo/evento", {"token": tok, "beacon": "AA:BB:CC:DD:EE:01", "modo": "aula"}).get_json()
        self.assertTrue(ev["liberado"])
        self.assertEqual(ev["aluno"], nome)
        return disp, tok

    # --------------------------------------------------------------- testes
    def test_fluxo_completo(self):
        adm, ed, sala, prof, livro = self.montar_escola_completa()
        disp, tok = self.computador_do_aluno(adm)
        aluno = self.id_de("alunos", "nome", "Bruno Aluno")

        # aluno chegou e aparece como pendente no painel do adm; adm coloca na sala
        self.assertIn(b"Bruno Aluno", adm.get("/adm/").data)
        adm.post("/adm/alunos", {"acao": "sala", "aluno": aluno, "sala": sala})
        self.assertNotIn(b"Colocar na sala", adm.get("/adm/").data)

        # Area do Estudante: livro, caderno
        est = Navegador(self.app)
        self.assertEqual(est.get("/estudante/entrar?dispositivo=" + tok).status_code, 302)
        pag = est.get("/estudante/?aba=livros").data.decode()
        self.assertIn("Matemática 7", pag)
        leitor = est.get("/estudante/livros/%d" % livro)
        self.assertEqual(leitor.status_code, 200)
        self.assertIn("/estudante/livros/%d.pdf" % livro, leitor.data.decode())
        r = est.get("/estudante/livros/%d.pdf" % livro)
        self.assertEqual(r.status_code, 200)
        self.assertTrue(r.data.startswith(b"%PDF"))
        r = est.post("/estudante/caderno", {"acao": "novo", "titulo": "Ciências"})
        cad = int(re.search(r"c=(\d+)", r.headers["Location"]).group(1))
        j = est.post("/estudante/caderno", {"acao": "salvar", "caderno": cad, "texto": "Fotossíntese"}).get_json()
        self.assertTrue(j["ok"])
        self.assertIn("Fotossíntese", est.get("/estudante/?aba=caderno&c=%d" % cad).data.decode())

        # Professor: prova com escrita, selecao e desenho
        pr = self.entrar("professores", "paulo@escola.com", "prof-senha-1")
        self.assertIn("7º A", pr.get("/professores/").data.decode())
        r = pr.post("/professores/atividades/nova", {"tipo": "prova", "titulo": "Prova 1", "sala": sala})
        ativ = int(r.headers["Location"].rsplit("/", 1)[1])
        pr.post("/professores/atividades/%d" % ativ, {"acao": "questao", "tipo": "escrita", "enunciado": "O que é fração?"})
        pr.post("/professores/atividades/%d" % ativ, {"acao": "questao", "tipo": "selecao", "enunciado": "2+2?",
                                                     "opcoes": "3\n4\n5", "correta": "2"})
        pr.post("/professores/atividades/%d" % ativ, {"acao": "questao", "tipo": "desenho", "enunciado": "Desenhe um triângulo"})
        # antes de publicar o aluno nao ve
        self.assertNotIn("Prova 1", est.get("/estudante/?aba=atividades").data.decode())
        pr.post("/professores/atividades/%d" % ativ, {"acao": "publicar"})
        self.assertIn("Prova 1", est.get("/estudante/?aba=atividades").data.decode())

        with self.app.app_context():
            qs = [q["id"] for q in self.app.todos("SELECT id FROM questoes WHERE atividade_id=? ORDER BY ordem", ativ)]
        r = est.post("/estudante/atividades/%d" % ativ, {"q%d" % qs[0]: "Parte de um todo", "q%d" % qs[1]: "1",
                                                         "q%d" % qs[2]: PNG})
        self.assertEqual(r.status_code, 302)
        # nao pode enviar duas vezes
        self.assertEqual(est.post("/estudante/atividades/%d" % ativ, {"q%d" % qs[0]: "x"}).status_code, 400)
        resp = pr.get("/professores/atividades/%d/respostas" % ativ).data.decode()
        self.assertIn("Bruno Aluno", resp)
        self.assertIn("1/1 certas", resp)
        self.assertIn("Parte de um todo", resp)
        self.assertIn('src="data:image/png;base64,', resp)

        # Ocorrencia do professor aparece para o adm
        pr.post("/professores/salas/%d" % sala, {"aluno": aluno, "texto": "Conversou durante a prova"})
        self.assertIn("Conversou durante a prova", adm.get("/adm/").data.decode())

    def test_ciclo_julho_janeiro(self):
        adm, ed, sala, prof, livro = self.montar_escola_completa()
        disp, tok = self.computador_do_aluno(adm)
        aluno = self.id_de("alunos", "nome", "Bruno Aluno")
        plataforma.ciclo_atual = lambda d=None: "2026-2"
        adm.post("/adm/alunos", {"acao": "sala", "aluno": aluno, "sala": sala})
        est = Navegador(self.app)
        est.get("/estudante/entrar?dispositivo=" + tok)
        self.assertIn("Matemática 7", est.get("/estudante/").data.decode())
        # virou o ciclo (01/01): aluno sem sala ate passar pelo beacon e o adm redistribuir
        plataforma.ciclo_atual = lambda d=None: "2027-1"
        self.assertNotIn("Matemática 7", est.get("/estudante/").data.decode())
        pendentes = lambda: re.search(r"precisam de sala \((\d+)\)", adm.get("/adm/").data.decode()).group(1)
        self.assertEqual(pendentes(), "0")        # ainda nao passou pelo beacon no ciclo novo
        disp.api("/api/dispositivo/evento", {"token": tok, "beacon": "AA:BB:CC:DD:EE:01", "modo": "aula"})
        self.assertEqual(pendentes(), "1")        # agora aparece para o adm
        adm.post("/adm/alunos", {"acao": "sala", "aluno": aluno, "sala": sala})
        self.assertIn("Matemática 7", est.get("/estudante/").data.decode())

    def test_isolamento_entre_escolas_e_seguranca(self):
        adm1, ed, sala1, prof1, livro = self.montar_escola_completa()
        adm2 = self.nova_escola("Outra Escola", "adm2@outra.com")
        self.assertEqual(adm2.get("/adm/salas/%d" % sala1).status_code, 404)
        self.assertNotIn(b"7\xc2\xba A", adm2.get("/adm/salas").data)
        # professor nao acessa sala em que nao da aula
        adm2.post("/adm/professores", {"nome": "Zé", "email": "ze@outra.com", "senha": "senha-ze-12"})
        ze = self.entrar("professores", "ze@outra.com", "senha-ze-12")
        self.assertEqual(ze.get("/professores/salas/%d" % sala1).status_code, 404)
        # areas exigem login com o papel certo
        self.assertEqual(Navegador(self.app).get("/adm/").status_code, 302)
        self.assertEqual(ze.get("/adm/").status_code, 302)
        # CSRF: POST sem token e recusado
        self.assertEqual(adm1.post("/adm/salas", {"nome": "X"}, csrf=False).status_code, 400)
        # senha errada
        n = Navegador(self.app)
        self.assertIn("incorretos", n.post("/adm/entrar", {"email": "adm@escola.com", "senha": "errada!!"}).data.decode())
        # computador nao liberado ve so o codigo
        disp = Navegador(self.app)
        reg = disp.api("/api/dispositivo/registrar", {"nome": "pc"}).get_json()
        est = Navegador(self.app)
        est.get("/estudante/entrar?dispositivo=" + reg["token"])
        r = est.get("/estudante/")
        self.assertEqual(r.status_code, 403)
        self.assertIn(reg["codigo"], r.data.decode())
        self.assertEqual(est.get("/estudante/livros/%d.pdf" % livro).status_code, 403)
        # token invalido na API
        self.assertEqual(disp.api("/api/dispositivo/evento", {"token": "falso"}).status_code, 403)
        # editora so aceita PDF
        r = ed.post("/editora/", {"acao": "publicar", "titulo": "Falso", "pdf": (io.BytesIO(b"MZ..."), "x.pdf")},
                    content_type="multipart/form-data")
        self.assertEqual(r.status_code, 400)

    def test_subdominios(self):
        self.nova_escola()
        adm = Navegador(self.app, host="adm.tualalios.com.br")
        r = adm.get("/")
        self.assertEqual(r.status_code, 302)
        self.assertIn("/adm/entrar", r.headers["Location"])
        prof = Navegador(self.app, host="professores.tualalios.com.br")
        self.assertIn("Professores", prof.get("/entrar").data.decode())
        self.assertIn(b"Tualali Escola", Navegador(self.app, host="tualalios.com.br").get("/").data)


if __name__ == "__main__":
    unittest.main()
