# Plataforma Tualali Escola

Sistema web da escola, usado pelo Modo Aula do Tualali OS. Python 3 + Flask + SQLite, sem outras dependências.

| Área | Endereço | Quem usa |
|---|---|---|
| Administração | `adm.tualalios.com.br` (ou `/adm`) | adms das escolas: cadastram a escola, professores, salas, horários, alunos, computadores e beacons |
| Professores | `professores.tualalios.com.br` (ou `/professores`) | salas, ocorrências, provas e atividades (escrita, seleção, desenho) e respostas |
| Editoras | `tualalios.com.br/editora` | publicam livros (PDF) |
| Estudante | `/estudante` | aberta pelo computador do aluno: Livro, Caderno, Atividades |
| API | `/api/dispositivo/*` | Modo Aula do Tualali (registrar, beacons, evento) |

Professores não criam conta: quem cria é o adm da escola. Cada escola só vê os próprios dados.

## Testar no computador
```
sudo apt install python3-flask
python3 demo.py           # opcional: dados de exemplo (senha demo12345)
python3 app.py            # http://127.0.0.1:5055
python3 -m unittest -v tests/test_plataforma.py
```

## Colocar no ar (servidor Debian/Ubuntu)
1. Compre o domínio `tualalios.com.br` e aponte `tualalios.com.br`, `adm.`, `professores.` e `estudante.` para o servidor (registros DNS A).
2. `sudo apt install python3-flask gunicorn nginx certbot python3-certbot-nginx`
3. Copie a pasta `plataforma` para `/opt/tualali-escola` e crie o usuário de serviço:
   `sudo useradd -r -d /var/lib/tualali-escola tualali && sudo mkdir -p /var/lib/tualali-escola && sudo chown tualali /var/lib/tualali-escola`
4. Crie o serviço `/etc/systemd/system/tualali-escola.service`:
   ```
   [Service]
   User=tualali
   Environment=TUALALI_DADOS=/var/lib/tualali-escola TUALALI_HTTPS=1
   WorkingDirectory=/opt/tualali-escola
   ExecStart=/usr/bin/gunicorn -w 3 -b 127.0.0.1:5055 'app:criar_app()'
   Restart=always
   [Install]
   WantedBy=multi-user.target
   ```
   e rode `sudo systemctl enable --now tualali-escola`.
5. Configure o nginx para encaminhar os quatro nomes para `127.0.0.1:5055`, com `client_max_body_size 300m;`
   (por causa dos livros), e ative o HTTPS com `sudo certbot --nginx`.
6. **Backup diário** da pasta `/var/lib/tualali-escola`: ela tem o banco `escola.db`, os livros e a chave secreta.

## Dados pessoais (LGPD)
A plataforma guarda dados de crianças e adolescentes: nomes, respostas, ocorrências e anotações.
- A escola precisa da autorização dos responsáveis e de uma pessoa responsável pelos dados.
- O servidor precisa usar HTTPS e ter backups.
- As senhas são guardadas só em forma de hash, nunca o texto da senha.
