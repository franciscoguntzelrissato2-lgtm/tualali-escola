// Quadro de desenho das respostas (mouse, touchpad, caneta ou dedo)
document.querySelectorAll('canvas.desenho').forEach(function (cv) {
  var ctx = cv.getContext('2d'), riscou = false, desenhando = false, cor = '#1c2333', largura = 3;
  ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, cv.width, cv.height);
  ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  var caixa = cv.closest('.questao');
  var campo = caixa.querySelector('input[name="' + cv.dataset.campo + '"]');
  function ponto(e) {
    var r = cv.getBoundingClientRect();
    return [(e.clientX - r.left) * cv.width / r.width, (e.clientY - r.top) * cv.height / r.height];
  }
  cv.addEventListener('pointerdown', function (e) {
    desenhando = true; cv.setPointerCapture(e.pointerId);
    var p = ponto(e); ctx.beginPath(); ctx.moveTo(p[0], p[1]);
  });
  cv.addEventListener('pointermove', function (e) {
    if (!desenhando) return;
    var p = ponto(e); ctx.strokeStyle = cor; ctx.lineWidth = largura; ctx.lineTo(p[0], p[1]); ctx.stroke(); riscou = true;
  });
  function parar() { if (desenhando) { desenhando = false; if (riscou) campo.value = cv.toDataURL('image/png'); } }
  cv.addEventListener('pointerup', parar); cv.addEventListener('pointercancel', parar);
  caixa.querySelectorAll('[data-cor]').forEach(function (b) {
    b.addEventListener('click', function () { cor = b.dataset.cor; largura = +(b.dataset.largura || 3); });
  });
  var limpar = caixa.querySelector('[data-limpar]');
  if (limpar) limpar.addEventListener('click', function () {
    ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, cv.width, cv.height); campo.value = ''; riscou = false;
  });
});
