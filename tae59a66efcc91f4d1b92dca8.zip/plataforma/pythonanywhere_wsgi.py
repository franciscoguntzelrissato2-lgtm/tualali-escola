# Arquivo WSGI para o PythonAnywhere (aba "Web" -> "WSGI configuration file").
# Troque USUARIO pelo seu nome de usuario do PythonAnywhere.
import os
import sys

USUARIO = "TuaLaliOS"
os.environ["TUALALI_DADOS"] = "/home/%s/tualali-dados" % USUARIO   # banco, livros e chave (fica salvo)
os.environ["TUALALI_HTTPS"] = "1"
sys.path.insert(0, "/home/%s/plataforma" % USUARIO)

from app import criar_app  # noqa: E402

application = criar_app()
