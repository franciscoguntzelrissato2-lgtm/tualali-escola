"""Plataforma escolar Tualali.

Areas (por caminho ou subdominio):
  /adm         adm.tualalios.com.br         administradores da escola
  /professores professores.tualalios.com.br professores
  /editora     tualalios.com.br/editora     editoras (publicam livros)
  /estudante   (aberta pelo computador do aluno, Modo Aula do Tualali)
  /api/dispositivo/...                       API usada pelo Tualali (beacon/Modo Aula)

Rodar para teste:  python3 app.py   (http://127.0.0.1:5055)
Producao: ver README.md (gunicorn + HTTPS).
"""
import datetime
import functools
import json
import os
import re
import secrets
import sqlite3
import uuid

from flask import (Flask, abort, flash, g, jsonify, redirect, render_template, request,
                   send_file, session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

AQUI = os.path.dirname(os.path.abspath(__file__))
DIAS = ["Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado", "Domingo"]
AREAS = ("adm", "professores", "editora", "estudante")


def ciclo_atual(d=None):
    """Ciclo letivo: 01/01-30/07 = <ano>-1 ; 31/07-31/12 = <ano>-2.
    Na virada do ciclo os alunos ficam sem sala ate o adm redistribuir."""
    d = d or datetime.date.today()
    return "%d-%d" % (d.year, 2 if (d.month, d.day) >= (7, 31) else 1)


class SubdominioParaCaminho:
    """adm.dominio/x -> /adm/x (o mesmo app atende subdominios e caminhos)."""

    def __init__(self, app):
        self.app = app

    def __call__(self, environ, start_response):
        host = environ.get("HTTP_HOST", "").split(":")[0].lower()
        sub = host.split(".")[0]
        caminho = environ.get("PATH_INFO", "/")
        if sub in AREAS and not caminho.startswith(("/" + sub, "/static", "/api/")):
            environ["PATH_INFO"] = "/" + sub + (caminho if caminho != "/" else "/")
        return self.app(environ, start_response)


def criar_app(config=None):
    app = Flask(__name__, instance_path=os.environ.get("TUALALI_DADOS", os.path.join(AQUI, "dados")))
    os.makedirs(app.instance_path, exist_ok=True)
    os.makedirs(os.path.join(app.instance_path, "livros"), exist_ok=True)
    chave = os.path.join(app.instance_path, "chave-secreta")
    if not os.path.exists(chave):
        with open(chave, "w") as f:
            f.write(secrets.token_hex(32))
        os.chmod(chave, 0o600)
    with open(chave) as f:
        segredo = f.read().strip()
    app.config.update(
        SECRET_KEY=segredo,
        BANCO=os.path.join(app.instance_path, "escola.db"),
        MAX_CONTENT_LENGTH=300 * 1024 * 1024,
        SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=os.environ.get("TUALALI_HTTPS") == "1",
    )
    if config:
        app.config.update(config)
    app.wsgi_app = SubdominioParaCaminho(app.wsgi_app)

    # ------------------------------------------------------------------ banco
    def db():
        if "db" not in g:
            g.db = sqlite3.connect(app.config["BANCO"])
            g.db.row_factory = sqlite3.Row
            g.db.execute("PRAGMA foreign_keys = ON")
        return g.db

    @app.teardown_appcontext
    def fechar(_e):
        c = g.pop("db", None)
        if c is not None:
            c.close()

    with app.app_context():
        with open(os.path.join(AQUI, "schema.sql")) as f:
            db().executescript(f.read())
        db().commit()

    def um(sql, *a):
        return db().execute(sql, a).fetchone()

    def todos(sql, *a):
        return db().execute(sql, a).fetchall()

    def exe(sql, *a):
        c = db().execute(sql, a)
        db().commit()
        return c.lastrowid

    app.um, app.todos, app.exe = um, todos, exe   # usados nos testes

    # ------------------------------------------------------------- seguranca
    @app.before_request
    def csrf():
        if request.method == "POST" and not request.path.startswith("/api/"):
            tok = request.form.get("csrf") or request.headers.get("X-CSRF")
            if not tok or tok != session.get("csrf"):
                abort(400, "Sessão expirada. Volte e tente de novo.")

    @app.context_processor
    def globais():
        if "csrf" not in session:
            session["csrf"] = secrets.token_urlsafe(24)
        return {"csrf": session["csrf"], "usuario": usuario_atual(), "DIAS": DIAS,
                "ciclo": ciclo_atual()}

    def usuario_atual():
        uid = session.get("uid")
        return um("SELECT * FROM usuarios WHERE id=?", uid) if uid else None

    def exige(papel):
        def deco(f):
            @functools.wraps(f)
            def w(*a, **k):
                u = usuario_atual()
                if not u or u["papel"] != papel:
                    return redirect(url_for("entrar", area=papel_area(papel), proximo=request.path))
                g.u = u
                return f(*a, **k)
            return w
        return deco

    def papel_area(p):
        return {"adm": "adm", "professor": "professores", "editora": "editora"}[p]

    def form(campo, obrig=True, maximo=500):
        v = (request.form.get(campo) or "").strip()
        if obrig and not v:
            abort(400, "Preencha o campo: %s" % campo)
        return v[:maximo]

    def da_escola(tabela, id_):
        """Busca um registro garantindo que e da escola do usuario (isolamento entre escolas)."""
        r = um("SELECT * FROM %s WHERE id=? AND escola_id=?" % tabela, id_, g.u["escola_id"])
        if not r:
            abort(404)
        return r

    # ------------------------------------------------------------- publico
    @app.route("/")
    def inicio():
        return render_template("inicio.html")

    @app.route("/<area>/entrar", methods=["GET", "POST"])
    def entrar(area):
        papel = {"adm": "adm", "professores": "professor", "editora": "editora"}.get(area)
        if not papel:
            abort(404)
        if request.method == "POST":
            u = um("SELECT * FROM usuarios WHERE email=? AND papel=?", form("email"), papel)
            if u and check_password_hash(u["senha_hash"], form("senha")):
                session.clear()
                session["uid"] = u["id"]
                destino = request.args.get("proximo", "")
                return redirect(destino if destino.startswith("/" + area) else "/" + area + "/")
            flash("E-mail ou senha incorretos.")
        return render_template("entrar.html", area=area, papel=papel)

    @app.route("/sair")
    def sair():
        session.clear()
        return redirect("/")

    def senha_ok(s):
        if len(s) < 8:
            abort(400, "A senha precisa ter pelo menos 8 caracteres.")
        return generate_password_hash(s)

    def email_livre(e):
        if not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", e):
            abort(400, "E-mail inválido.")
        if um("SELECT 1 FROM usuarios WHERE email=?", e):
            abort(400, "Este e-mail já está cadastrado.")
        return e

    @app.route("/adm/cadastro", methods=["GET", "POST"])
    def cadastro_adm():
        if request.method == "POST":
            email = email_livre(form("email"))
            esc = exe("INSERT INTO escolas(nome, cidade) VALUES(?,?)", form("escola"), form("cidade", False))
            uid = exe("INSERT INTO usuarios(escola_id,papel,nome,email,senha_hash) VALUES(?,?,?,?,?)",
                      esc, "adm", form("nome"), email, senha_ok(form("senha")))
            session.clear()
            session["uid"] = uid
            return redirect("/adm/")
        return render_template("cadastro.html", area="adm")

    @app.route("/editora/cadastro", methods=["GET", "POST"])
    def cadastro_editora():
        if request.method == "POST":
            email = email_livre(form("email"))
            uid = exe("INSERT INTO usuarios(papel,nome,email,senha_hash,editora) VALUES(?,?,?,?,?)",
                      "editora", form("nome"), email, senha_ok(form("senha")), form("editora"))
            session.clear()
            session["uid"] = uid
            return redirect("/editora/")
        return render_template("cadastro.html", area="editora")

    # ------------------------------------------------------------------ adm
    @app.route("/adm/")
    @exige("adm")
    def adm_painel():
        e = g.u["escola_id"]
        c = ciclo_atual()
        return render_template(
            "adm/painel.html",
            escola=um("SELECT * FROM escolas WHERE id=?", e),
            pendentes=todos("SELECT * FROM alunos WHERE escola_id=? AND visto_ciclo=? "
                            "AND (sala_ciclo IS NULL OR sala_ciclo<>?) ORDER BY nome", e, c, c),
            novos=todos("SELECT * FROM dispositivos WHERE escola_id=? AND aluno_id IS NULL "
                        "ORDER BY ultimo_contato DESC", e),
            salas=todos("SELECT * FROM salas WHERE escola_id=? ORDER BY nome", e),
            ocorrencias=todos("SELECT o.*, a.nome aluno, u.nome professor FROM ocorrencias o "
                              "JOIN alunos a ON a.id=o.aluno_id JOIN usuarios u ON u.id=o.professor_id "
                              "WHERE o.escola_id=? ORDER BY o.criado DESC LIMIT 30", e),
            totais={k: um("SELECT COUNT(*) n FROM %s WHERE escola_id=?" % t, e)["n"] for k, t in
                    (("alunos", "alunos"), ("salas", "salas"), ("computadores", "dispositivos"))},
        )

    @app.route("/adm/professores", methods=["GET", "POST"])
    @exige("adm")
    def adm_professores():
        if request.method == "POST":
            exe("INSERT INTO usuarios(escola_id,papel,nome,email,senha_hash) VALUES(?,?,?,?,?)",
                g.u["escola_id"], "professor", form("nome"), email_livre(form("email")),
                senha_ok(form("senha")))
            flash("Professor cadastrado. Passe o e-mail e a senha para ele entrar em professores.")
            return redirect("/adm/professores")
        return render_template("adm/professores.html", professores=todos(
            "SELECT * FROM usuarios WHERE escola_id=? AND papel='professor' ORDER BY nome", g.u["escola_id"]))

    @app.route("/adm/salas", methods=["GET", "POST"])
    @exige("adm")
    def adm_salas():
        if request.method == "POST":
            exe("INSERT INTO salas(escola_id,nome,serie) VALUES(?,?,?)", g.u["escola_id"], form("nome"),
                form("serie", False))
            return redirect("/adm/salas")
        return render_template("adm/salas.html", salas=todos(
            "SELECT s.*, (SELECT COUNT(*) FROM alunos a WHERE a.sala_id=s.id AND a.sala_ciclo=?) n "
            "FROM salas s WHERE escola_id=? ORDER BY nome", ciclo_atual(), g.u["escola_id"]))

    @app.route("/adm/salas/<int:sid>", methods=["GET", "POST"])
    @exige("adm")
    def adm_sala(sid):
        s = da_escola("salas", sid)
        if request.method == "POST":
            acao = form("acao")
            if acao == "horario":
                p = um("SELECT * FROM usuarios WHERE id=? AND escola_id=? AND papel='professor'",
                       int(form("professor")), g.u["escola_id"])
                if not p:
                    abort(400, "Professor inválido.")
                dia = int(form("dia"))
                if not 0 <= dia <= 6:
                    abort(400, "Dia inválido.")
                exe("INSERT INTO horarios(sala_id,professor_id,disciplina,dia,inicio,fim) VALUES(?,?,?,?,?,?)",
                    sid, p["id"], form("disciplina"), dia, form("inicio"), form("fim"))
            elif acao == "remover_horario":
                exe("DELETE FROM horarios WHERE id=? AND sala_id=?", int(form("horario")), sid)
            elif acao == "livros":
                exe("DELETE FROM livros_sala WHERE sala_id=?", sid)
                for lid in request.form.getlist("livro"):
                    if um("SELECT 1 FROM livros WHERE id=?", int(lid)):
                        exe("INSERT OR IGNORE INTO livros_sala VALUES(?,?)", sid, int(lid))
                flash("Livros da sala atualizados.")
            return redirect("/adm/salas/%d" % sid)
        return render_template(
            "adm/sala.html", sala=s,
            alunos=todos("SELECT * FROM alunos WHERE sala_id=? AND sala_ciclo=? ORDER BY nome", sid, ciclo_atual()),
            horarios=todos("SELECT h.*, u.nome professor FROM horarios h JOIN usuarios u ON u.id=h.professor_id "
                           "WHERE sala_id=? ORDER BY dia, inicio", sid),
            professores=todos("SELECT * FROM usuarios WHERE escola_id=? AND papel='professor' ORDER BY nome",
                              g.u["escola_id"]),
            livros=todos("SELECT l.*, u.editora, (SELECT 1 FROM livros_sala x WHERE x.sala_id=? AND "
                         "x.livro_id=l.id) marcado FROM livros l JOIN usuarios u ON u.id=l.editora_id "
                         "ORDER BY l.serie, l.titulo", sid))

    @app.route("/adm/alunos", methods=["GET", "POST"])
    @exige("adm")
    def adm_alunos():
        e = g.u["escola_id"]
        if request.method == "POST":
            acao = form("acao")
            if acao == "criar":
                sala = request.form.get("sala") or None
                if sala:
                    da_escola("salas", int(sala))
                exe("INSERT INTO alunos(escola_id,nome,matricula,sala_id,sala_ciclo) VALUES(?,?,?,?,?)",
                    e, form("nome"), form("matricula", False), sala, ciclo_atual() if sala else None)
            elif acao == "sala":
                a = da_escola("alunos", int(form("aluno")))
                da_escola("salas", int(form("sala")))
                exe("UPDATE alunos SET sala_id=?, sala_ciclo=? WHERE id=?", int(form("sala")), ciclo_atual(), a["id"])
                flash("%s foi colocado na sala." % a["nome"])
            return redirect(request.form.get("voltar") or "/adm/alunos")
        c = ciclo_atual()
        return render_template("adm/alunos.html", salas=todos("SELECT * FROM salas WHERE escola_id=? ORDER BY nome", e),
                               alunos=todos("SELECT a.*, CASE WHEN a.sala_ciclo=? THEN s.nome END sala "
                                            "FROM alunos a LEFT JOIN salas s ON s.id=a.sala_id "
                                            "WHERE a.escola_id=? ORDER BY a.nome", c, e))

    @app.route("/adm/computadores", methods=["GET", "POST"])
    @exige("adm")
    def adm_computadores():
        e = g.u["escola_id"]
        if request.method == "POST":
            d = da_escola("dispositivos", int(form("dispositivo")))
            if form("acao") == "vincular":
                aluno = request.form.get("aluno")
                if aluno == "novo":
                    aid = exe("INSERT INTO alunos(escola_id,nome,matricula) VALUES(?,?,?)", e, form("nome"),
                              form("matricula", False))
                else:
                    aid = da_escola("alunos", int(aluno))["id"]
                exe("UPDATE dispositivos SET aluno_id=? WHERE id=?", aid, d["id"])
                exe("UPDATE alunos SET visto_ciclo=?, visto_em=? WHERE id=?", ciclo_atual(), d["ultimo_contato"], aid)
                flash("Computador %s ligado ao aluno." % d["codigo"])
            elif form("acao") == "desvincular":
                exe("UPDATE dispositivos SET aluno_id=NULL WHERE id=?", d["id"])
            return redirect("/adm/computadores")
        return render_template(
            "adm/computadores.html",
            dispositivos=todos("SELECT d.*, a.nome aluno FROM dispositivos d LEFT JOIN alunos a ON a.id=d.aluno_id "
                               "WHERE d.escola_id=? ORDER BY d.aluno_id IS NOT NULL, d.ultimo_contato DESC", e),
            alunos=todos("SELECT * FROM alunos WHERE escola_id=? AND id NOT IN (SELECT aluno_id FROM dispositivos "
                         "WHERE aluno_id IS NOT NULL) ORDER BY nome", e))

    @app.route("/adm/beacons", methods=["GET", "POST"])
    @exige("adm")
    def adm_beacons():
        if request.method == "POST":
            if form("acao") == "criar":
                ident = form("identificador").strip()
                if um("SELECT 1 FROM beacons WHERE identificador=?", ident):
                    abort(400, "Este beacon já está cadastrado.")
                exe("INSERT INTO beacons(escola_id,identificador,nome) VALUES(?,?,?)", g.u["escola_id"], ident,
                    form("nome", False))
            else:
                exe("DELETE FROM beacons WHERE id=? AND escola_id=?", int(form("beacon")), g.u["escola_id"])
            return redirect("/adm/beacons")
        return render_template("adm/beacons.html", beacons=todos(
            "SELECT * FROM beacons WHERE escola_id=? ORDER BY nome", g.u["escola_id"]))

    # ------------------------------------------------------------ professor
    def salas_do_professor():
        return todos("SELECT DISTINCT s.* FROM salas s JOIN horarios h ON h.sala_id=s.id WHERE h.professor_id=? "
                     "ORDER BY s.nome", g.u["id"])

    def sala_do_professor(sid):
        s = um("SELECT s.* FROM salas s JOIN horarios h ON h.sala_id=s.id WHERE s.id=? AND h.professor_id=?",
               sid, g.u["id"])
        if not s:
            abort(404)
        return s

    def atividade_do_professor(aid):
        a = um("SELECT a.*, s.nome sala FROM atividades a JOIN salas s ON s.id=a.sala_id "
               "WHERE a.id=? AND a.professor_id=?", aid, g.u["id"])
        if not a:
            abort(404)
        return a

    @app.route("/professores/")
    @exige("professor")
    def prof_painel():
        return render_template(
            "prof/painel.html", salas=salas_do_professor(),
            horarios=todos("SELECT h.*, s.nome sala FROM horarios h JOIN salas s ON s.id=h.sala_id "
                           "WHERE professor_id=? ORDER BY dia, inicio", g.u["id"]),
            atividades=todos("SELECT a.*, s.nome sala, (SELECT COUNT(*) FROM respostas r WHERE r.atividade_id=a.id) n "
                             "FROM atividades a JOIN salas s ON s.id=a.sala_id WHERE professor_id=? "
                             "ORDER BY a.criado DESC", g.u["id"]))

    @app.route("/professores/salas/<int:sid>", methods=["GET", "POST"])
    @exige("professor")
    def prof_sala(sid):
        s = sala_do_professor(sid)
        if request.method == "POST":
            al = um("SELECT * FROM alunos WHERE id=? AND sala_id=? AND sala_ciclo=?", int(form("aluno")), sid,
                    ciclo_atual())
            if not al:
                abort(400, "Aluno não está nesta sala.")
            exe("INSERT INTO ocorrencias(escola_id,aluno_id,professor_id,texto) VALUES(?,?,?,?)",
                s["escola_id"], al["id"], g.u["id"], form("texto", maximo=4000))
            flash("Ocorrência registrada.")
            return redirect("/professores/salas/%d" % sid)
        return render_template(
            "prof/sala.html", sala=s,
            alunos=todos("SELECT * FROM alunos WHERE sala_id=? AND sala_ciclo=? ORDER BY nome", sid, ciclo_atual()),
            ocorrencias=todos("SELECT o.*, a.nome aluno FROM ocorrencias o JOIN alunos a ON a.id=o.aluno_id "
                              "WHERE a.sala_id=? AND o.professor_id=? ORDER BY o.criado DESC", sid, g.u["id"]))

    @app.route("/professores/atividades/nova", methods=["GET", "POST"])
    @exige("professor")
    def prof_nova():
        if request.method == "POST":
            s = sala_do_professor(int(form("sala")))
            tipo = form("tipo")
            if tipo not in ("prova", "atividade"):
                abort(400)
            aid = exe("INSERT INTO atividades(escola_id,sala_id,professor_id,titulo,tipo,prazo) VALUES(?,?,?,?,?,?)",
                      s["escola_id"], s["id"], g.u["id"], form("titulo"), tipo, form("prazo", False))
            return redirect("/professores/atividades/%d" % aid)
        return render_template("prof/nova.html", salas=salas_do_professor())

    @app.route("/professores/atividades/<int:aid>", methods=["GET", "POST"])
    @exige("professor")
    def prof_atividade(aid):
        a = atividade_do_professor(aid)
        if request.method == "POST":
            acao = form("acao")
            if acao == "questao":
                tipo = form("tipo")
                if tipo not in ("escrita", "selecao", "desenho"):
                    abort(400)
                opcoes, correta = None, None
                if tipo == "selecao":
                    linhas = [x.strip() for x in form("opcoes", maximo=4000).splitlines() if x.strip()]
                    if len(linhas) < 2:
                        abort(400, "Coloque pelo menos 2 opções, uma por linha.")
                    opcoes = "\n".join(linhas)
                    correta = int(request.form.get("correta") or 1) - 1
                    if not 0 <= correta < len(linhas):
                        abort(400, "Número da resposta certa inválido.")
                n = um("SELECT COUNT(*) n FROM questoes WHERE atividade_id=?", aid)["n"]
                exe("INSERT INTO questoes(atividade_id,ordem,tipo,enunciado,opcoes,correta) VALUES(?,?,?,?,?,?)",
                    aid, n + 1, tipo, form("enunciado", maximo=4000), opcoes, correta)
            elif acao == "remover":
                exe("DELETE FROM questoes WHERE id=? AND atividade_id=?", int(form("questao")), aid)
            elif acao == "publicar":
                if not um("SELECT 1 FROM questoes WHERE atividade_id=?", aid):
                    abort(400, "Adicione pelo menos uma pergunta antes de publicar.")
                exe("UPDATE atividades SET publicada=1 WHERE id=?", aid)
                flash("Publicada! Os alunos da sala já podem responder.")
            return redirect("/professores/atividades/%d" % aid)
        return render_template("prof/atividade.html", a=a, questoes=questoes_de(aid))

    def questoes_de(aid):
        return [dict(q, lista=(q["opcoes"] or "").split("\n") if q["opcoes"] else [])
                for q in todos("SELECT * FROM questoes WHERE atividade_id=? ORDER BY ordem", aid)]

    @app.route("/professores/atividades/<int:aid>/respostas")
    @exige("professor")
    def prof_respostas(aid):
        a = atividade_do_professor(aid)
        qs = questoes_de(aid)
        lista = []
        for r in todos("SELECT r.*, al.nome aluno FROM respostas r JOIN alunos al ON al.id=r.aluno_id "
                       "WHERE atividade_id=? ORDER BY al.nome", aid):
            itens = {i["questao_id"]: i["valor"] for i in todos("SELECT * FROM resposta_itens WHERE resposta_id=?",
                                                                   r["id"])}
            sel = [q for q in qs if q["tipo"] == "selecao"]
            acertos = sum(1 for q in sel if itens.get(q["id"]) == str(q["correta"]))
            lista.append({"r": r, "itens": itens, "acertos": acertos, "total_sel": len(sel)})
        return render_template("prof/respostas.html", a=a, questoes=qs, lista=lista)

    # -------------------------------------------------------------- editora
    @app.route("/editora/", methods=["GET", "POST"])
    @exige("editora")
    def editora_painel():
        if request.method == "POST":
            if form("acao") == "publicar":
                f = request.files.get("pdf")
                if not f or not f.filename:
                    abort(400, "Escolha o arquivo PDF do livro.")
                cabeca = f.stream.read(5)
                f.stream.seek(0)
                if cabeca != b"%PDF-":
                    abort(400, "O arquivo precisa ser um PDF.")
                nome = uuid.uuid4().hex + ".pdf"
                f.save(os.path.join(app.instance_path, "livros", nome))
                exe("INSERT INTO livros(editora_id,titulo,autor,serie,arquivo) VALUES(?,?,?,?,?)",
                    g.u["id"], form("titulo"), form("autor", False), form("serie", False), nome)
                flash("Livro publicado. As escolas já podem escolher este livro para as salas.")
            elif form("acao") == "remover":
                l = um("SELECT * FROM livros WHERE id=? AND editora_id=?", int(form("livro")), g.u["id"])
                if l:
                    exe("DELETE FROM livros WHERE id=?", l["id"])
                    try:
                        os.remove(os.path.join(app.instance_path, "livros", l["arquivo"]))
                    except OSError:
                        pass
            return redirect("/editora/")
        return render_template("editora/painel.html", livros=todos(
            "SELECT l.*, (SELECT COUNT(*) FROM livros_sala x WHERE x.livro_id=l.id) salas FROM livros l "
            "WHERE editora_id=? ORDER BY criado DESC", g.u["id"]))

    # ------------------------------------------------------------ estudante
    def aluno_atual():
        d = um("SELECT * FROM dispositivos WHERE token=?", session.get("dispositivo", ""))
        if not d or not d["aluno_id"]:
            return None, d
        return um("SELECT * FROM alunos WHERE id=?", d["aluno_id"]), d

    def exige_aluno(f):
        @functools.wraps(f)
        def w(*a, **k):
            al, d = aluno_atual()
            if not al:
                return render_template("estudante/aguardando.html", d=d), 403
            g.aluno = al
            g.sala_ok = al["sala_ciclo"] == ciclo_atual() and al["sala_id"]
            return f(*a, **k)
        return w

    @app.route("/estudante/entrar")
    def estudante_entrar():
        tok = request.args.get("dispositivo", "")
        if not um("SELECT 1 FROM dispositivos WHERE token=?", tok):
            abort(403, "Computador não registrado.")
        session.clear()
        session["dispositivo"] = tok
        aba = request.args.get("aba", "")
        return redirect("/estudante/" + ("?aba=" + aba if aba in ("livros", "caderno", "atividades") else ""))

    @app.route("/estudante/")
    @exige_aluno
    def estudante():
        al = g.aluno
        livros, atividades = [], []
        if g.sala_ok:
            livros = todos("SELECT l.* FROM livros l JOIN livros_sala x ON x.livro_id=l.id WHERE x.sala_id=? "
                           "ORDER BY l.titulo", al["sala_id"])
            atividades = todos("SELECT a.*, u.nome professor, (SELECT 1 FROM respostas r WHERE r.atividade_id=a.id "
                               "AND r.aluno_id=?) feita FROM atividades a JOIN usuarios u ON u.id=a.professor_id "
                               "WHERE a.sala_id=? AND a.publicada=1 ORDER BY a.criado DESC", al["id"], al["sala_id"])
        return render_template("estudante/inicio.html", aluno=al, livros=livros, atividades=atividades,
                               sala=um("SELECT * FROM salas WHERE id=?", al["sala_id"]) if g.sala_ok else None,
                               cadernos=todos("SELECT * FROM cadernos WHERE aluno_id=? ORDER BY atualizado DESC",
                                              al["id"]),
                               aba=request.args.get("aba", "livros"))

    def livro_do_aluno(lid):
        if not g.sala_ok:
            abort(403)
        l = um("SELECT l.* FROM livros l JOIN livros_sala x ON x.livro_id=l.id WHERE l.id=? AND x.sala_id=?",
               lid, g.aluno["sala_id"])
        if not l:
            abort(404)
        return l

    @app.route("/estudante/livros/<int:lid>")
    @exige_aluno
    def estudante_leitor(lid):
        return render_template("estudante/leitor.html", livro=livro_do_aluno(lid))

    @app.route("/estudante/livros/<int:lid>.pdf")
    @exige_aluno
    def estudante_livro(lid):
        l = livro_do_aluno(lid)
        return send_file(os.path.join(app.instance_path, "livros", l["arquivo"]), mimetype="application/pdf",
                         download_name=re.sub(r"[^\w\- ]", "", l["titulo"]) + ".pdf", as_attachment=False)

    @app.route("/estudante/caderno", methods=["POST"])
    @exige_aluno
    def estudante_caderno():
        acao = form("acao")
        if acao == "novo":
            cid = exe("INSERT INTO cadernos(aluno_id,titulo) VALUES(?,?)", g.aluno["id"], form("titulo", maximo=120))
            return redirect("/estudante/?aba=caderno&c=%d" % cid)
        c = um("SELECT * FROM cadernos WHERE id=? AND aluno_id=?", int(form("caderno")), g.aluno["id"])
        if not c:
            abort(404)
        if acao == "salvar":
            exe("UPDATE cadernos SET texto=?, atualizado=datetime('now','localtime') WHERE id=?",
                (request.form.get("texto") or "")[:200000], c["id"])
            return jsonify(ok=True, salvo=datetime.datetime.now().strftime("%H:%M:%S"))
        if acao == "apagar":
            exe("DELETE FROM cadernos WHERE id=?", c["id"])
        return redirect("/estudante/?aba=caderno")

    @app.route("/estudante/atividades/<int:aid>", methods=["GET", "POST"])
    @exige_aluno
    def estudante_atividade(aid):
        if not g.sala_ok:
            abort(403)
        a = um("SELECT a.*, u.nome professor FROM atividades a JOIN usuarios u ON u.id=a.professor_id "
               "WHERE a.id=? AND a.sala_id=? AND a.publicada=1", aid, g.aluno["sala_id"])
        if not a:
            abort(404)
        qs = questoes_de(aid)
        feita = um("SELECT * FROM respostas WHERE atividade_id=? AND aluno_id=?", aid, g.aluno["id"])
        if request.method == "POST":
            if feita:
                abort(400, "Você já enviou esta atividade.")
            rid = exe("INSERT INTO respostas(atividade_id,aluno_id) VALUES(?,?)", aid, g.aluno["id"])
            for q in qs:
                v = request.form.get("q%d" % q["id"], "")
                if q["tipo"] == "desenho" and v and not v.startswith("data:image/png;base64,"):
                    v = ""
                exe("INSERT INTO resposta_itens(resposta_id,questao_id,valor) VALUES(?,?,?)", rid, q["id"],
                    v[:3_000_000])
            flash("Atividade enviada para o professor!")
            return redirect("/estudante/?aba=atividades")
        itens = {}
        if feita:
            itens = {i["questao_id"]: i["valor"] for i in todos("SELECT * FROM resposta_itens WHERE resposta_id=?",
                                                                   feita["id"])}
        return render_template("estudante/atividade.html", a=a, questoes=qs, feita=feita, itens=itens)

    # -------------------------------------------------- API do dispositivo
    def api_dispositivo():
        dados = request.get_json(silent=True) or {}
        d = um("SELECT * FROM dispositivos WHERE token=?", str(dados.get("token", "")))
        if not d:
            abort(403, "dispositivo desconhecido")
        return d, dados

    @app.route("/api/dispositivo/registrar", methods=["POST"])
    def api_registrar():
        dados = request.get_json(silent=True) or {}
        tok = secrets.token_urlsafe(32)
        while True:
            codigo = "".join(secrets.choice("ABCDEFGHJKLMNPQRSTUVWXYZ23456789") for _ in range(6))
            if not um("SELECT 1 FROM dispositivos WHERE codigo=?", codigo):
                break
        exe("INSERT INTO dispositivos(token,codigo,nome) VALUES(?,?,?)", tok, codigo,
            str(dados.get("nome", ""))[:80])
        return jsonify(token=tok, codigo=codigo)

    @app.route("/api/dispositivo/beacons", methods=["POST"])
    def api_beacons():
        api_dispositivo()
        return jsonify(beacons=[b["identificador"] for b in todos("SELECT identificador FROM beacons")])

    @app.route("/api/dispositivo/evento", methods=["POST"])
    def api_evento():
        d, dados = api_dispositivo()
        agora = datetime.datetime.now().isoformat(timespec="seconds")
        modo = "aula" if dados.get("modo") == "aula" else "livre"
        b = um("SELECT * FROM beacons WHERE identificador=?", str(dados.get("beacon", "")))
        escola = d["escola_id"]
        if b and b["escola_id"] != escola:
            escola = b["escola_id"]          # computador chegou (ou mudou) de escola
            if d["escola_id"] and d["aluno_id"]:
                exe("UPDATE dispositivos SET aluno_id=NULL WHERE id=?", d["id"])
        exe("UPDATE dispositivos SET escola_id=?, modo=?, ultimo_contato=? WHERE id=?", escola, modo, agora, d["id"])
        d = um("SELECT * FROM dispositivos WHERE id=?", d["id"])
        aluno = None
        if d["aluno_id"]:
            exe("UPDATE alunos SET visto_ciclo=?, visto_em=? WHERE id=?", ciclo_atual(), agora, d["aluno_id"])
            aluno = um("SELECT nome FROM alunos WHERE id=?", d["aluno_id"])["nome"]
        return jsonify(ok=True, codigo=d["codigo"], aluno=aluno, liberado=bool(aluno))

    @app.errorhandler(400)
    @app.errorhandler(403)
    @app.errorhandler(404)
    def erro(e):
        if request.path.startswith("/api/"):
            return jsonify(erro=e.description), e.code
        return render_template("erro.html", e=e), e.code

    return app


if __name__ == "__main__":
    criar_app().run(host=os.environ.get("TUALALI_HOST", "127.0.0.1"), port=int(os.environ.get("PORT", 5055)))
