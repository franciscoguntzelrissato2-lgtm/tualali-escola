"""Cria dados de demonstracao (escola, professor, editora, livro, aluno com computador, prova).
Uso: TUALALI_DADOS=/tmp/demo python3 demo.py   -> imprime os acessos."""
import io
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from tests.test_plataforma import PDF, Navegador  # noqa: E402
import app as plataforma  # noqa: E402

a = plataforma.criar_app()
adm = Navegador(a)
adm.post("/adm/cadastro", {"escola": "Colégio Tualali", "cidade": "São Paulo", "nome": "Ana Diretora",
                           "email": "adm@demo.com", "senha": "demo12345"})
adm.post("/adm/professores", {"nome": "Paulo Souza", "email": "prof@demo.com", "senha": "demo12345"})
adm.post("/adm/salas", {"nome": "7º ano A", "serie": "7º ano"})
with a.app_context():
    sala = a.um("SELECT id FROM salas")["id"]
    prof = a.um("SELECT id FROM usuarios WHERE email='prof@demo.com'")["id"]
adm.post("/adm/salas/%d" % sala, {"acao": "horario", "professor": prof, "disciplina": "Matemática", "dia": 0,
                                  "inicio": "07:30", "fim": "08:20"})
adm.post("/adm/beacons", {"acao": "criar", "identificador": "AA:BB:CC:DD:EE:01", "nome": "Porta do 7º A"})
ed = Navegador(a)
ed.post("/editora/cadastro", {"editora": "Editora Saber", "nome": "Eva", "email": "editora@demo.com",
                              "senha": "demo12345"})
ed.post("/editora/", {"acao": "publicar", "titulo": "Matemática — 7º ano", "autor": "Eva Lima", "serie": "7º ano",
                      "pdf": (io.BytesIO(PDF), "mat.pdf")}, content_type="multipart/form-data")
with a.app_context():
    livro = a.um("SELECT id FROM livros")["id"]
adm.post("/adm/salas/%d" % sala, {"acao": "livros", "livro": livro})
# computador do aluno passa pelo beacon e e ligado ao aluno
d = Navegador(a)
reg = d.api("/api/dispositivo/registrar", {"nome": "macbook-air"}).get_json()
d.api("/api/dispositivo/evento", {"token": reg["token"], "beacon": "AA:BB:CC:DD:EE:01", "modo": "aula"})
with a.app_context():
    did = a.um("SELECT id FROM dispositivos")["id"]
adm.post("/adm/computadores", {"acao": "vincular", "dispositivo": did, "aluno": "novo", "nome": "Bruno Lima"})
d.api("/api/dispositivo/evento", {"token": reg["token"], "beacon": "AA:BB:CC:DD:EE:01", "modo": "aula"})
# segundo computador ainda nao ligado
reg2 = d.api("/api/dispositivo/registrar", {"nome": "pc-sala"}).get_json()
d.api("/api/dispositivo/evento", {"token": reg2["token"], "beacon": "AA:BB:CC:DD:EE:01", "modo": "aula"})
pr = Navegador(a)
pr.post("/professores/entrar", {"email": "prof@demo.com", "senha": "demo12345"})
r = pr.post("/professores/atividades/nova", {"tipo": "prova", "titulo": "Prova de frações", "sala": sala})
at = int(r.headers["Location"].rsplit("/", 1)[1])
pr.post("/professores/atividades/%d" % at, {"acao": "questao", "tipo": "selecao", "enunciado": "Quanto é 1/2 + 1/4?",
                                            "opcoes": "2/6\n3/4\n1/8", "correta": "2"})
pr.post("/professores/atividades/%d" % at, {"acao": "questao", "tipo": "escrita", "enunciado": "Explique o que é uma fração."})
pr.post("/professores/atividades/%d" % at, {"acao": "questao", "tipo": "desenho", "enunciado": "Desenhe uma pizza dividida em 4 partes."})
pr.post("/professores/atividades/%d" % at, {"acao": "publicar"})
print("adm@demo.com / prof@demo.com / editora@demo.com  senha demo12345")
print("estudante: /estudante/entrar?dispositivo=" + reg["token"])
print("TOKEN=" + reg["token"])
